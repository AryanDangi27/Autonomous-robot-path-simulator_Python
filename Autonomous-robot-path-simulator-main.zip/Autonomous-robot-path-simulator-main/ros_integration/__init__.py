"""Optional ROS integration layer."""
